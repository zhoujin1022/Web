function $(id){
	return typeof id==='string'?document.getElementById(id):id;
}
	window.onload=function(){
		var titles=$('steps').getElementsByTagName('li'),
			divs=$('notice-con').getElementsByTagName('div');
			var next=document.getElementById('next'),
				 pre=document.getElementById('pre');
			if(titles.length!=divs.length)
				return;	
				for(var i=0;i<titles.length;i++){
						titles[i].id=i;
						divs[i].id=i;

						next.onclick=function(){	
								
								for(var j=0;j<titles.length;j++){
									var a=titles[j].className;
									
									if(a=="select"&&titles[j].id!=3){
										for(var k=0;k<titles.length;k++){
											titles[k].className='';
											divs[k].style.display="none";	
										}
										titles[j+1].className='select';
										divs[j+1].style.display="block";
										break;
									}
									if(titles[j+1].id==3){
										next.href="application-blank.html";
									}
									
																
								}
							
						}
					pre.onclick=function(){
						for(var j=0;j<titles.length;j++){
									var a=titles[j].className;
									if(a=="select"&&titles[j].id!=0)	{
										for(var k=0;k<titles.length;k++){
											titles[k].className='';
											divs[k].style.display="none";	
										}
										titles[j-1].className='select';
										divs[j-1].style.display="block";
										break;
									}
									// if(titles[j].id==0){
									// 	pre.href="application-blank.html";
									// }
																
								}

					}

						// titles[i].onclick=function(){
						// 	for(var j=0;j<titles.length;j++){
						// 		titles[j].className='';
						// 		divs[j].style.display="none";
						// 	}
						// 	this.className='select';
						// 	divs[this.id].style.display="block";
						// }
				}	

}


	
