
function preview(file,num)

{
	var prevDiv = document.getElementById('preview-'+num);
	if (file.files && file.files[0])
	{
		var reader = new FileReader();
		reader.onload = function(evt){
			prevDiv.innerHTML = '<img src="' + evt.target.result + '" />';
		}  
		reader.readAsDataURL(file.files[0]);
	}else  
	{
		prevDiv.innerHTML = '上传失败,请重新上传！';
	}
}
function more(c){
	if(c>8){
		alert("上传资料已达上限！");
		return;
	}
 	var more=document.getElementById('more-'+c);
 	var PDiv=document.getElementById('up');
 	var childDiv=document.createElement("div");
 	var input=document.createElement("input");
 	var div=document.createElement("div");
 	div.appendChild(childDiv);
 	div.appendChild(input);
 	PDiv.appendChild(div);
 	div.setAttribute("class","up1"+" up-"+c); 
	 	childDiv.setAttribute("class","preview");
	 	childDiv.setAttribute("id","preview-"+c);
	 	input.setAttribute("type","file");
	 	input.setAttribute("onchange","preview(this,"+c+")");
	 PDiv.insertBefore(div,more); 
	 c++;
	 more.setAttribute("href","javascript:more("+c+")");
	 more.setAttribute("class","more");
	 more.setAttribute("id","more-"+c);


 }