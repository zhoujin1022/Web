
function preview(file,num)

{
	var prevDiv = document.getElementById('preview-'+num);
	if (file.files && file.files[0])
	{
		var reader = new FileReader();
		reader.onload = function(evt){
			prevDiv.innerHTML = '<img src="' + evt.target.result + '" />';
		}  
		reader.readAsDataURL(file.files[0]);
	}else  
	{
		prevDiv.innerHTML = '上传失败,请重新上传！';
	}
}
function more(c){
	if(c>8){
		alert("上传资料已达上限！");
		return;
	}
 	var more=document.getElementById('more-'+c);
 	var PDiv=document.getElementById('up');
 	var childDiv=document.createElement("div");
 	var input=document.createElement("input");
 	var div=document.createElement("div");
 	div.appendChild(childDiv);
 	div.appendChild(input);
 	PDiv.appendChild(div);
 	div.setAttribute("class","up1"+" up-"+c); 
	 	childDiv.setAttribute("class","preview");
	 	childDiv.setAttribute("id","preview-"+c);
	 	input.setAttribute("type","file");
	 	input.setAttribute("onchange","preview(this,"+c+")");
	 PDiv.insertBefore(div,more); 
	 c++;
	 more.setAttribute("href","javascript:more("+c+")");
	 more.setAttribute("class","more");
	 more.setAttribute("id","more-"+c);


 }

 function dianji(){
 	 var select=document.getElementById('select');
 	 	// select.style.overflow='initial';
 	 if(select.style.overflow=='hidden'){
 	 	select.style.overflow='initial';
 	 }else{
 	 	select.style.overflow='hidden';
 	 }
 }
 function sel(a){

 	var select1="&#xe613;"+document.getElementById('op'+a).innerHTML;
 	var myselect=document.getElementById('my-select').innerHTML;
 	if(document.getElementById('my-select').innerHTML!=null){
 	document.getElementById('my-select').innerHTML =myselect+"&nbsp;&nbsp;&nbsp;"+select1;
 }else{
 	document.getElementById('my-select').innerHTML=select1;
 }
 	
 }

 function que(){
 	document.getElementById('my-select').innerHTML=null;
 }
 // function wancheng(){
 // 	var myselect=document.getElementById('my-select').innerHTML;
 // 	if(myselect==""){
 // 		alert('至少选取一种类型！');
 // 	}
 // 	else{
 // 	alert('请上传扫描资料！');
 // 	var information=document.getElementById('information');
 // 	information.style.display='block';
 // 	var wancheng=document.getElementById('wancheng');
 // 	wancheng.setAttribute("style","color:#FF6A00;");
 // 	}
 // }

