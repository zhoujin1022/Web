$(document).ready(function(){
	//浮窗控制代码
	$(".flo-a").click(function(){
		$(".flo-window").hide();
	});
	$(".flo-window span").click(function(){
		$(".flo-window").hide();
		iframes=$('.con-switch iframe');
		for(var m=0;m<iframes.length;m++){
				iframes[m].style.display='none';
			}
		iframes[1].style.display='block';
		// produce(1);
	});
	$(".li a").click(function(){
		alis=$(".li a");
		for(i=11;i<16;i++){
			$(alis[i-11]).removeClass("li-v");
		}
		$(this).addClass("li-v");
	});
	//Tag标签点击切换
	$(".control-li a").live('click',function(){
		$(".li-v").removeClass("li-v");
		$(".control-li-c").removeClass("control-li-c");
		change_iframe=jQuery(this).attr("id");		
		num=change_iframe.substr(3);
		$(".control-li-c").removeClass("control-li-c");
		alis=$(".li a");
		$(alis[num-1]).addClass("li-v");
		$("#"+num).addClass("control-li-c");
		iframe_f=$('.con-switch iframe');
		for(var m=0;m<iframe_f.length;m++){
				iframe_f[m].style.display='none';
			}
		iframe_f[num].style.display='block';
	});
})
window.onload=function(){
	//获取鼠标滑过或点击标签和要切换内容的元素
	iframes=$('.con-switch iframe');
	for(var i=1;i<iframes.length;i++){
	        iframes[i].style.display='none';
	    }
	var titles=$('.fea-list li');
	//遍历titles下所有的li
	for(var i=1;i<titles.length;i++){
		titles[i].id=i+10;
		titles[i].onclick=function(){
			//清除所有li上的class
			for(var j=0;j<titles.length;j++){
				iframes[j].style.display='none';
			}
			//显示相应iframe
			iframes[this.id-10].style.display='block';
		}
	}
}

//产生tag标签
function produce(a){
    var fea_list_id = String($("#1"+a).attr("id"));
    var control_ul_id = String($("#"+a).attr("id"));
	if(control_ul_id.substr(0) == fea_list_id.substr(1)){
		$(".control-li-c").removeClass("control-li-c");
		$("#"+a).addClass("control-li-c");
		return;
    }
	else{
		var $addCon = "<li class='control-li' id='"+a+"' ><a href='#' id='tag"+a+"'></a><span id='close"+a+"' onclick='modify("+a+")'>&#xea0f;</span></li>";
		$(".control-ul").append($addCon);
		$(".control-li-c").removeClass("control-li-c");
		$("#"+a).addClass("control-li-c");
		var fea_list_text=$(".a"+(a+1)).html();
		$("#tag"+a).append(fea_list_text);
	}	
 }

//Tag标签的关闭功能
function modify(b){
    iframes=$('.con-switch iframe');
    alis=$(".li a");
	iframes[b].style.display='none';
	$("#"+b).remove(); 
	for(var i=0;i<iframes.length;i++){
	    iframes[i].style.display='none';
	}
	tits=$(".control-wd li");
	$(".control-li-c").removeClass("control-li-c");
	$(".li-v").removeClass("li-v"); 
	if (tits.length==0) {
		return;
	}     
	tit_mid=tits.length-1;
	$(tits[tit_mid]).addClass("control-li-c");
	var z=tits.length-1;
	var tit_max=tits[z].id;
	iframes[tit_max].style.display='block';        
	$(alis[tit_max-1]).addClass("li-v");      
 }